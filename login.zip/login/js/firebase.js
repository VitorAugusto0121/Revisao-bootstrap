const firebaseConfig = {
  apiKey: "AIzaSyDekNsl02zYXC8IWnwdw3jhXj8OSZAEImY",
  authDomain: "login-5c259.firebaseapp.com",
  projectId: "login-5c259",
  storageBucket: "login-5c259.appspot.com",
  messagingSenderId: "757808319009",
  appId: "1:757808319009:web:7b4c69b52fb2139689b160",
  measurementId: "G-PFT2ZNJK4N"
};
firebase.initializeApp(firebaseConfig);
firebase.analytics();