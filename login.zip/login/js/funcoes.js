const loadComponents = () => {
	const auth = firebase.auth();

	const googleProvider = new firebase.auth.GoogleAuthProvider();
	auth.signInWithPopup(googleProvider)
	.then(function(result) {
		var user = result.user;
		alert(user.email)

	})
	.catch(error => {
		console.error(error);
	})
}	

function cadastrar(googleAccount){
	if (googleAccount == true){
	}else if (googleAccount == false) {
		var db = firebase.firestore();
		
		let valueNome = document.getElementById("floatingName").value;
		let valueEmail = document.getElementById("floatingInput").value;
		let valuePassword = document.getElementById("floatingPassword").value;
		emailVerification = false;
		db.collection("usuario").where("Email", "==", valueEmail)
		.get()
		.then((querySnapshot) => {
			querySnapshot.forEach((doc) => {
				emailVerification = true;
			});
			if (!emailVerification == true){
				db.collection("usuario").add({
					Nome: valueNome,
					Email: valueEmail,
					Senha: valuePassword
				})
				.then((docRef) => {
					console.log("Document written with ID: ", docRef.id);
					window.location = "index.html?"+ valueNome+"?"+ docRef.id
				})
				.catch((error) => {
					console.error("Error adding document: ", error);
				});
			}else if(emailVerification == true){
				alert("Esse email já está registrado")
			}
		})
		.catch((error) => {
			console.log("Error getting documents: ", error);
		});
	}
}

function login(){
	let loginEmail = document.getElementById('floatingInput').value
	let senha = document.getElementById('floatingPassword').value
	var db = firebase.firestore();

	db.collection("usuario").where("Email", "==", loginEmail)
	.get()
	.then((querySnapshot) => {
		querySnapshot.forEach((doc) => {
			if (doc.data().Senha == senha){
				console.log(doc.id, " => ", doc.data());
				window.location = "index.html?"+  doc.data().Nome +"?"+doc.data().id
			}else{
				alert("Senha errada!")
			}
		});
	})
	.catch((error) => {
		console.log("Error getting documents: ", error);
	});
}